#include <stdio.h>

#define ROWS 5
#define COLS 5

void affiche_matrice(int Mat[ROWS][COLS]) {
    int i, j, c;

    printf("\nLes elements de la matrice sont :\n\n");

    for (i = 0; i < ROWS; i++) {
        if (i == 0) {
            for (c = 1; c <= COLS; c++)
                printf("[%d] \t", c);
            printf("\n");
        }

        for (j = 0; j < COLS; j++) {
            printf("%d \t", Mat[i][j]);
            if (j == COLS - 1) {
                printf("\n");
            }
        }
    }
}

int main() {
    int Mat[ROWS][COLS] = {
        {1, 2, 3, 4, 5},
        {6, 7, 8, 9, 10},
        {11, 12, 13, 14, 15},
        {16, 17, 18, 19, 20},
        {20, 21, 22, 23, 24}
    };

    affiche_matrice(Mat);

    /* 
    // pour saiser les elements de la matrice 
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            printf("Element %d: ", j + 1);
            scanf("%d", &Mat[i][j]);
        }
    }
    */

    return 0;
}

