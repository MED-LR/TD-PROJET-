#include <stdio.h>
#include <ctype.h>

int main() {
    char character;
    int digits = 0, spaces = 0, others = 0;

    printf("Enter a sequence of characters (press Enter to finish):\n");

    while ((character = getchar()) != '\n') {
        if (isdigit(character)) {
            digits++;
        } else if (isspace(character)) {
            spaces++;
        } else {
            others++;
        }
    }

    printf("Digits: %d\n", digits);
    printf("Spaces: %d\n", spaces);
    printf("Others: %d\n", others);

    return 0;
}

