#include <stdio.h>
char cMessage[] = "Hello, World! 123";
void crypt(char *caractere) {
    if ((*caractere >= 'a' && *caractere <= 'z') || (*caractere >= 'A' && *caractere <= 'Z')) {
        *caractere += 5;

        if ((*caractere > 'z' && *caractere <= 'z' + 5) || (*caractere > 'Z' && *caractere <= 'Z' + 5)) {
            *caractere -= 26;
        }
    }
}

int main() {
    int i;


    for (i = 0; cMessage[i] != '\0'; i++) {
        crypt(&cMessage[i]);
    }


    printf("Message crypte : %s\n", cMessage);

    return 0;
}

