#include <stdio.h>

int addition(int A, int B) {
    return A + B;
}

int soustraction(int A, int B) {
    return A - B;
}

int multiplication(int A, int B) {
    return A * B;
}

int division(int A, int B) {
    if (B != 0) {
        return A / B;
    } else {
        printf("Erreur : Division par zero.\n");
        return 0;
    }
}

int modulo(int A, int B) {
    if (B != 0) {
        return A % B;
    } else {
        printf("Erreur : Division par zero.\n");
        return 0;
    }
}

int main() {
    char choix;
    do {
        int nombre1, nombre2, resultat;
        char operateur;

       
        printf("Entrez une expression (entier operateur entier) : ");
        scanf("%d %c %d", &nombre1, &operateur, &nombre2);

       
        switch (operateur) {
            case '+':
                resultat = addition(nombre1, nombre2);
                break;
            case '-':
                resultat = soustraction(nombre1, nombre2);
                break;
            case '*':
                resultat = multiplication(nombre1, nombre2);
                break;
            case '/':
                resultat = division(nombre1, nombre2);
                break;
            case '%':
                resultat = modulo(nombre1, nombre2);
                break;
            default:
                printf("Operateur non valide.\n");
                continue; 
        }

        printf("Resultat : %d\n", resultat);

    
        printf("Voulez-vous recommencer? (O/N) : ");
        scanf(" %c", &choix);

    } while (choix == 'O' || choix == 'o');

    return 0;
}

