#include <stdio.h>

int iNb_jours[13];  


void initialiser_iNb_jours() {
    int i;

    for (i = 1; i <= 12; i++) {
        if (i == 2)
            iNb_jours[i] = 28;
        else if ((i % 2 == 0 && i <= 7) || (i % 2 != 0 && i > 7))
            iNb_jours[i] = 30;
        else
            iNb_jours[i] = 31;
    }
}


void imprimer_iNb_jours() {
    int i;

    printf("Nombre de jours pour chaque mois :\n");
    for (i = 1; i <= 12; i++) {
        printf("Mois %d : %d jours\n", i, iNb_jours[i]);
    }
}

void imprimer_nb_jours_mois(int mois) {
    if (mois >= 1 && mois <= 12) {
        printf("Mois %d : %d jours\n", mois, iNb_jours[mois]);
    } else {
        printf("Mois invalide.\n");
    }
}

int main() {
    initialiser_iNb_jours();

    imprimer_iNb_jours();

    int mois;
    printf("\nEntrez un mois (entre 1 et 12) : ");
    scanf("%d", &mois);
    imprimer_nb_jours_mois(mois);

    return 0;
}
