
#include <stdio.h>


char cTab1[] = "Bonjour";
char cTab2[] = "Hello, World!";


int longueur_chaine(char tableau[]) {
    int longueur = 0;


    while (tableau[longueur] != '\0') {
        longueur++;
    }

    return longueur;
}

int main() {
    printf("Nombre d'elements dans cTab1 : %d\n", longueur_chaine(cTab1));

    printf("Nombre d'elements dans cTab2 : %d\n", longueur_chaine(cTab2));

    return 0;
}



