#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_STRING_LENGTH 100


void saisir(char chaine[MAX_STRING_LENGTH]) {
    printf("Entrez une chaine de caracteres : ");
    scanf(" %[^\n]", chaine);
}


void afficher(const char chaine[MAX_STRING_LENGTH]) {
    printf("La cha�ne est : %s\n", chaine);
}


char* inverser(const char chaine[MAX_STRING_LENGTH]) {
    int longueur = strlen(chaine);
    char* chaineInverse = (char*)malloc((longueur + 1) * sizeof(char));

    int i, j;
    for (i = 0, j = longueur - 1; i < longueur; i++, j--) {
        chaineInverse[i] = chaine[j];
    }

    chaineInverse[longueur] = '\0';  

    return chaineInverse;
}


int compterMots(const char chaine[MAX_STRING_LENGTH]) {
    int mots = 0;
    int enMot = 0; 

    int i;
    for (i = 0; i < strlen(chaine); i++) {
        if (chaine[i] == ' ' || chaine[i] == '\t' || chaine[i] == '\n') {
            
            enMot = 0;
        } else {
            
            if (!enMot) {
                enMot = 1;
                mots++;
            }
        }
    }

    return mots;
}

int main() {
    char chaine[MAX_STRING_LENGTH];
    int choix;

    int i;

    do {
        printf("\nMenu :\n");
        printf("1. Saisir une chaine\n");
        printf("2. Afficher la chaine\n");
        printf("3. Inverser la chaine\n");
        printf("4. Compter le nombre de mots\n");
        printf("5. Quitter\n");
        printf("Choisissez une operation (1-5) : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                saisir(chaine);
                break;
            case 2:
                afficher(chaine);
                break;
            case 3: {
                char* chaineInverse = inverser(chaine);
                printf("Chaine inversee : %s\n", chaineInverse);
                free(chaineInverse);  
                break;
            }
            case 4:
                printf("Nombre de mots dans la chaine : %d\n", compterMots(chaine));
                break;
            case 5:
                printf("Programme termine.\n");
                break;
            default:
                printf("Choix non valide.\n");
        }

        printf("Frapper une touche pour revenir au menu.\n");
        getchar(); 
        getchar(); 

    } while (choix != 5);

    return 0;
}


