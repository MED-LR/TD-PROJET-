#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int distanceH(const char *S1, const char *S2) {
    int len1 = strlen(S1);
    int len2 = strlen(S2);

    if (len1 != len2) {
        fprintf(stderr, "Les cha�nes doivent avoir la m�me longueur.\n");
        exit(EXIT_FAILURE);
    }

    int distance = 0;
    int i;

    for (i = 0; i < len1; i++) {
        if (S1[i] != S2[i]) {
            distance++;
        }
    }

    return distance;
}


int distanceH_langage(const char **langage, int tailleLangage) {
    if (tailleLangage <= 1) {
        fprintf(stderr, "Le langage doit contenir au moins deux chaines.\n");
        exit(EXIT_FAILURE);
    }

    int min_distance = distanceH(langage[0], langage[1]);

    int i, j;
    for (i = 0; i < tailleLangage - 1; i++) {
        for (j = i + 1; j < tailleLangage; j++) {
            int current_distance = distanceH(langage[i], langage[j]);
            if (current_distance < min_distance) {
                min_distance = current_distance;
            }
        }
    }

    return min_distance;
}


char *binaire(int N) {
    if (N < 0 || N > 255) {
        fprintf(stderr, "La valeur de N doit etre comprise entre 0 et 255 inclus.\n");
        exit(EXIT_FAILURE);
    }

    char *binaire_representation = (char *)malloc(9 * sizeof(char));

    if (binaire_representation == NULL) {
        fprintf(stderr, "Allocation de memoire echouee.\n");
        exit(EXIT_FAILURE);
    }

    int i;
    for (i = 7; i >= 0; i--) {
        binaire_representation[7 - i] = ((N >> i) & 1) + '0';
    }

    binaire_representation[8] = '\0';

    return binaire_representation;
}

int distanceNombre(int A, int B) {
    if (A < 0 || A > 255 || B < 0 || B > 255) {
        fprintf(stderr, "Les nombres A et B doivent �tre compris entre 0 et 255 inclus.\n");
        exit(EXIT_FAILURE);
    }

    char *binaire_A = binaire(A);
    char *binaire_B = binaire(B);

    int distance = 0;
    int j;

    for (j = 0; j < 8; j++) {
        if (binaire_A[j] != binaire_B[j]) {
            distance++;
        }
    }

    free(binaire_A);
    free(binaire_B);

    return distance;
}

int main() {

    int distance1 = distanceH("sure", "cure");
    printf("Distance de Hamming entre 'sure' et 'cure': %d\n", distance1);

    int distance2 = distanceH("aabbcc", "xaybzc");
    printf("Distance de Hamming entre 'aabbcc' et 'xaybzc': %d\n", distance2);


    const char *langage[] = {"aabb", "xayy", "tghy", "xgyy"};
    int tailleLangage = sizeof(langage) / sizeof(langage[0]);
    int distance_langage = distanceH_langage(langage, tailleLangage);
    printf("Distance de Hamming du langage: %d\n", distance_langage);

    int distance_nombre = distanceNombre(7, 4);
    printf("Distance de Hamming entre les nombres 7 et 4: %d\n", distance_nombre);

    return 0;
}


