#include <stdio.h>
#include <stdlib.h>
#define MAX_ELEMENTS 20

void displayMenu() {
    printf("\nA- Saisie et affichage\n");
    printf("B- Moyenne\n");
    printf("C- Suppression du Max et affichage\n");
    printf("D- Suppression du Min et affichage\n");
    printf("E- Ajout d'un entier a une position donnee\n");
    printf("Q- Quitter\n\n");
    printf("Faire un choix du menu\n");
}

char getMenuChoice() {
    char choice;
    scanf(" %c", &choice);
    return choice;
}

void inputArray(int array[], int size) {
    int i;
    for (i = 0; i < size; i++) {
        printf("Element N %d: ", i + 1);
        scanf("%d", &array[i]);
    }
}

void displayArray(int array[], int size) {
    int i;
    printf("Les elements du Tableau : \n");
    for (i = 0; i < size; i++) {
        printf("Element N %d = %d\n", i + 1, array[i]);
    }
}

float calculateAverage(int array[], int size) {
    int i, sum = 0;
    for (i = 0; i < size; i++) {
        sum += array[i];
    }
    return (float)sum / size;
}

int compareMax(int a, int b) {
    return a > b;
}

int compareMin(int a, int b) {
    return a < b;
}

int findExtremeElementIndex(int array[], int size, int (*compare)(int, int)) {
    int i, extreme = array[0], pos = 0;
    for (i = 1; i < size; i++) {
        if (compare(array[i], extreme)) {
            extreme = array[i];
            pos = i;
        }
    }
    return pos;
}

void removeElement(int array[], int size, int pos) {
    int i;
    for (i = pos; i < size - 1; i++) {
        array[i] = array[i + 1];
    }
}

void insertElement(int array[], int *size) {
    int i, val, pos;
    printf("Entrez la valeur a inserer: ");
    scanf("%d", &val);
    printf("Entrez la position ou inserer: ");
    scanf("%d", &pos);

    pos = pos - 1;

    for (i = *size - 1; i >= pos; i--) {
        array[i + 1] = array[i];
    }
    array[pos] = val;
    (*size)++;
}

int main() {
    int array[MAX_ELEMENTS];
    int size = 0;
    char choice;

    while (1) {
        displayMenu();
        choice = getMenuChoice();

        switch (choice) {
            case 'A':
            case 'a':
                printf("Saisir le nombre d'elements a inserer : ");
                scanf("%d", &size);
                if (size > MAX_ELEMENTS) {
                    printf("Saisir un nombre inferieur a 20");
                } else {
                    inputArray(array, size);
                    printf("\n\n");
                    displayArray(array, size);
                }
                break;
            case 'B':
            case 'b':
                printf("\nLa moyenne des elements du tableau est %.2f \n", calculateAverage(array, size));
                break;
            case 'C':
            case 'c':
                {
                    int maxIndex = findExtremeElementIndex(array, size, compareMax);
                    if (maxIndex >= 0) {
                        removeElement(array, size, maxIndex);
                        displayArray(array, --size);
                    } else {
                        printf("Array is empty or there was an issue finding the maximum element.\n");
                    }
                }
                break;
            case 'D':
            case 'd':
                {
                    int minIndex = findExtremeElementIndex(array, size, compareMin);
                    if (minIndex >= 0) {
                        removeElement(array, size, minIndex);
                        displayArray(array, --size);
                    } else {
                        printf("Array is empty or there was an issue finding the minimum element.\n");
                    }
                }
                break;
            case 'E':
            case 'e':
                insertElement(array, &size);
                displayArray(array, size);
                break;
            case 'Q':
            case 'q':
                exit(0);
            default:
                printf("Choix invalide. Veuillez reessayer.\n");
        }
    }

    return 0;
}


