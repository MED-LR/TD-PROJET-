#include <stdio.h>
#include <string.h>

#define MAX_NAME_LENGTH 20

void lireNom(char nom[MAX_NAME_LENGTH + 1]) {
    printf("Entrez un nom : ");
    scanf("%s", nom);
}


int aPlusDeDixCaracteres(char nom[MAX_NAME_LENGTH + 1]) {
    return (strlen(nom) > 10);
}

int main() {
    char nom[MAX_NAME_LENGTH + 1];
    int countNomsPlusDeDixCaracteres = 0;

    do {
        lireNom(nom);

        if (strcmp(nom, "fin") == 0) {
            break; 
        }

        if (strlen(nom) > MAX_NAME_LENGTH) {
            printf("Erreur : Le nom depasse la longueur maximale autorisee.\n");
            continue;
        }

        if (aPlusDeDixCaracteres(nom)) {
            countNomsPlusDeDixCaracteres++;
        }

    } while (1);

    printf("Nombre de noms ayant plus de dix caracteres : %d\n", countNomsPlusDeDixCaracteres);

    return 0;
}


