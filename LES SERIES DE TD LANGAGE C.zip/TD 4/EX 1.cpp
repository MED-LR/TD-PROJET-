
#include <stdio.h>

typedef struct {
    float reel;
    float imaginaire;
} Complexe;

float partieImaginaire(Complexe z) {
    return z.imaginaire;
}

float partieReelle(Complexe z) {
    return z.reel;
}

Complexe multiplication(Complexe z1, Complexe z2) {
    Complexe resultat;
    resultat.reel = z1.reel * z2.reel - z1.imaginaire * z2.imaginaire;
    resultat.imaginaire = z1.reel * z2.imaginaire + z1.imaginaire * z2.reel;
    return resultat;
}

void partieImaginaireParRef(Complexe *z, float *resultat) {
    *resultat = z->imaginaire;
}

void partieReelleParRef(Complexe *z, float *resultat) {
    *resultat = z->reel;
}

void multiplicationParRef(Complexe *z1, Complexe *z2, Complexe *resultat) {
    resultat->reel = z1->reel * z2->reel - z1->imaginaire * z2->imaginaire;
    resultat->imaginaire = z1->reel * z2->imaginaire + z1->imaginaire * z2->reel;
}

int main() {
    Complexe z1, z2, resultat;

    printf("Entrez la partie reelle du premier nombre complexe : ");
    scanf("%f", &z1.reel);
    printf("Entrez la partie imaginaire du premier nombre complexe : ");
    scanf("%f", &z1.imaginaire);

    printf("Entrez la partie reelle du deuxieme nombre complexe : ");
    scanf("%f", &z2.reel);
    printf("Entrez la partie imaginaire du deuxieme nombre complexe : ");
    scanf("%f", &z2.imaginaire);

    printf("z1 = %.2f + %.2fi\n", z1.reel, z1.imaginaire);
    printf("z2 = %.2f + %.2fi\n", z2.reel, z2.imaginaire);

    printf("Partie imaginaire de z1 : %.2f\n", partieImaginaire(z1));
    printf("Partie reelle de z2 : %.2f\n", partieReelle(z2));

    resultat = multiplication(z1, z2);
    printf("Multiplication : %.2f + %.2fi\n", resultat.reel, resultat.imaginaire);

    float resultatImaginaire, resultatReel;
    partieImaginaireParRef(&z1, &resultatImaginaire);
    printf("Partie imaginaire de z1 (par reference) : %.2f\n", resultatImaginaire);

    partieReelleParRef(&z2, &resultatReel);
    printf("Partie reelle de z2 (par reference) : %.2f\n", resultatReel);

    multiplicationParRef(&z1, &z2, &resultat);
    printf("Multiplication (par reference) : %.2f + %.2fi\n", resultat.reel, resultat.imaginaire);

    return 0;
}

