#include <stdio.h>

struct date {
    int jour;
    char mois[10];
    int annee;
};

struct employe {
    char nom[15];
    char prenom[15];
    struct date date_naissance;
    struct date date_embauche;
};

int main() {
    struct employe employes[4];
    int i;

    for (i = 0; i < 4; ++i) {
        printf("Entrez le nom de l'employe %d : ", i + 1);
        scanf("%s", employes[i].nom);

        printf("Entrez le pr�nom de l'employe %d : ", i + 1);
        scanf("%s", employes[i].prenom);

        printf("Entrez la date de naissance de l'employ� %d (jour mois annee) : ", i + 1);
        scanf("%d %s %d", &employes[i].date_naissance.jour, employes[i].date_naissance.mois, &employes[i].date_naissance.annee);

        printf("Entrez la date d'embauche de l'employe %d (jour mois annee) : ", i + 1);
        scanf("%d %s %d", &employes[i].date_embauche.jour, employes[i].date_embauche.mois, &employes[i].date_embauche.annee);

        printf("\n");
    }
    for (i = 0; i < 4; ++i) {
        printf("Nom: %s\n", employes[i].nom);
        printf("Prenom: %s\n", employes[i].prenom);
        printf("Date de naissance: %d %s %d\n", employes[i].date_naissance.jour,
               employes[i].date_naissance.mois, employes[i].date_naissance.annee);
        printf("Date d'embauche: %d %s %d\n", employes[i].date_embauche.jour,
               employes[i].date_embauche.mois, employes[i].date_embauche.annee);
        printf("\n");
    }

    return 0;
}

