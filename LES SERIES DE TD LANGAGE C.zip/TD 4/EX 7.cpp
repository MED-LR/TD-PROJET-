#include <stdio.h>


struct Produit {
    int reference;
    int code;
    float prix;
    int quantiteDisponible;
};

void saisirProduit(struct Produit *produit) {
    printf("Entrez la reference du produit : ");
    scanf("%d", &produit->reference);

    printf("Entrez le code du produit (1: Carte mere, 2: Processeur, 3: Barrette memoire, 4: Carte graphique) : ");
    scanf("%d", &produit->code);

    printf("Entrez le prix du produit en DH : ");
    scanf("%f", &produit->prix);

    printf("Entrez la quantite disponible du produit : ");
    scanf("%d", &produit->quantiteDisponible);
}

void afficherProduit(struct Produit produit) {
    printf("Reference : %d\n", produit.reference);
    printf("Code : %d\n", produit.code);
    printf("Prix : %.2f DH\n", produit.prix);
    printf("Quantit� disponible : %d\n", produit.quantiteDisponible);
}


void saisirCommande(struct Produit produit, int quantiteCommandee) {
    printf("\nCommande du produit :\n");
    afficherProduit(produit);

    float montantTotal = quantiteCommandee * produit.prix;
    printf("Quantite commandee : %d\n", quantiteCommandee);
    printf("Montant total de la commande : %.2f DH\n", montantTotal);
}

int main() {
    struct Produit produit;

    saisirProduit(&produit);

    printf("\nInformations du produit :\n");
    afficherProduit(produit);

    int quantiteCommandee;
    printf("\nEntrez la quantite que vous souhaitez commander : ");
    scanf("%d", &quantiteCommandee);

    saisirCommande(produit, quantiteCommandee);

    return 0;
}

