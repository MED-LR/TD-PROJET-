#include <stdio.h>
#include <stdlib.h>


typedef struct {
    int nb_elem;  
    int *tab;    
} TypeTableau;


TypeTableau CreationTableau(int n) {
    TypeTableau T;
    T.nb_elem = n;
    T.tab = (int *)malloc(n * sizeof(int)); 

    if (T.tab == NULL) {
        fprintf(stderr, "Erreur d'allocation de memoire\n");
        exit(EXIT_FAILURE);
    }

    return T;
}

void DestructionTableau(TypeTableau T) {
    free(T.tab);
}


void SimpleLectureTableau(TypeTableau T) {
    printf("Saisie des elements du tableau :\n");
    for (int i = 0; i < T.nb_elem; ++i) {
        printf("Element %d : ", i + 1);
        scanf("%d", &T.tab[i]);
    }
}


void Affichage(TypeTableau T) {
    printf("Contenu du tableau :\n");
    for (int i = 0; i < T.nb_elem; ++i) {
        printf("%d ", T.tab[i]);
    }
    printf("\n");
}


TypeTableau DoubleTableau(TypeTableau T) {
    TypeTableau nouveauTableau;
    nouveauTableau.nb_elem = T.nb_elem;
    nouveauTableau.tab = (int *)malloc(T.nb_elem * sizeof(int)); 

    if (nouveauTableau.tab == NULL) {
        fprintf(stderr, "Erreur d'allocation de memoire\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < T.nb_elem; ++i) {
        nouveauTableau.tab[i] = 2 * T.tab[i];
    }

    return nouveauTableau;
}

int main() {
    int n;


    printf("Entrez la taille du tableau : ");
    scanf("%d", &n);


    TypeTableau T = CreationTableau(n);

    SimpleLectureTableau(T);

    printf("\nTableau initial :\n");
    Affichage(T);

    TypeTableau T_double = DoubleTableau(T);

    printf("\nTableau avec les elements doubles :\n");
    Affichage(T_double);

    DestructionTableau(T);
    DestructionTableau(T_double);

    return 0;
}

