#include <stdio.h>

#define MAX_CONTACTS 100

struct Contact {
    char nom[30];
    char prenom[30];
    char telephone[15];
};

void afficherContacts(struct Contact contacts[], int nbContacts) {
    printf("Liste des contacts :\n");
    for (int i = 0; i < nbContacts; ++i) {
        printf("Contact %d :\n", i + 1);
        printf("Nom : %s\n", contacts[i].nom);
        printf("Prenom : %s\n", contacts[i].prenom);
        printf("Telephone : %s\n\n", contacts[i].telephone);
    }
}

int main() {
    struct Contact repertoire[MAX_CONTACTS];
    int nbContacts;

    printf("Combien de contacts souhaitez-vous ajouter ? (maximum %d) : ", MAX_CONTACTS);
    scanf("%d", &nbContacts);

    // Saisie des donn�es pour chaque contact
    for (int i = 0; i < nbContacts; ++i) {
        printf("\nContact %d :\n", i + 1);
        printf("Entrez le nom : ");
        scanf("%s", repertoire[i].nom);

        printf("Entrez le prenom : ");
        scanf("%s", repertoire[i].prenom);

        printf("Entrez le numero de telephone : ");
        scanf("%s", repertoire[i].telephone);
    }

    afficherContacts(repertoire, nbContacts);

    return 0;
}

