#include <stdio.h>

int nb_occurrence(char T[], int n, char c, int *p_occ, int *d_occ) {
    int occurrences = 0;
    *p_occ = -1; 
    *d_occ = -1; 

    for (int i = 0; i < n; ++i) {
        if (T[i] == c) {
            if (*p_occ == -1) {
                *p_occ = i; 
            }
            *d_occ = i; 
            occurrences++;
        }
    }

    return occurrences;
}

int main() {
    char T[100];
    char c;

    printf("Entrez une chaine de caracteres : ");
    fgets(T, sizeof(T), stdin);

    printf("Entrez le caractere pour lequel vous voulez compter les occurrences : ");
    scanf("%c", &c);

    int n = 0;
    while (T[n] != '\0' && T[n] != '\n') {
        n++;
    }

    int p_occurrence, d_occurrence;
    int occurrences = nb_occurrence(T, n, c, &p_occurrence, &d_occurrence);

    printf("Le nombre d'occurrences de '%c' est : %d\n", c, occurrences);
    if (occurrences > 0) {
        printf("Premiere occurrence a l'indice : %d\n", p_occurrence);
        printf("Derniere occurrence a l'indice : %d\n", d_occurrence);
    } else {
        printf("Le caractere '%c' n'a pas ete trouve.\n", c);
    }

    return 0;
}

