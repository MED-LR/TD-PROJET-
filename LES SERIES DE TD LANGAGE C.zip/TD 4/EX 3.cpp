#include <stdio.h>

struct etudiant {
    char nom[15];
    char prenom[15];
    int CNE;
    float notes[4];
    float moyenne;
};

void lireInformations(struct etudiant *etud) {
    printf("Entrez le nom de l'etudiant : ");
    scanf("%s", etud->nom);

    printf("Entrez le prenom de l'etudiant : ");
    scanf("%s", etud->prenom);

    printf("Entrez le CNE de l'etudiant : ");
    scanf("%d", &etud->CNE);

    printf("Entrez les notes de l'etudiant (4 notes separees par des espaces) : ");
    for (int i = 0; i < 4; ++i) {
        scanf("%f", &etud->notes[i]);
    }

    printf("\n");
}

void afficherInformations(struct etudiant etud) {
    printf("Nom: %s\n", etud.nom);
    printf("Prenom: %s\n", etud.prenom);
    printf("CNE: %d\n", etud.CNE);
    printf("Notes: %.2f, %.2f, %.2f, %.2f\n", etud.notes[0], etud.notes[1], etud.notes[2], etud.notes[3]);
    printf("Moyenne: %.2f\n", etud.moyenne);
    printf("\n");
}

void trierParMoyenneDecroissante(struct etudiant T[], int taille) {
    for (int i = 0; i < taille - 1; ++i) {
        for (int j = 0; j < taille - i - 1; ++j) {
            if (T[j].moyenne < T[j + 1].moyenne) {
                struct etudiant temp = T[j];
                T[j] = T[j + 1];
                T[j + 1] = temp;
            }
        }
    }
}

int main() {
    struct etudiant T[5];
    int index_max_moyenne = 0;
    int i;

    for (i = 0; i < 5; ++i) {
        lireInformations(&T[i]);
    }

    for (i = 1; i < 5; ++i) {
        if (T[i].moyenne > T[index_max_moyenne].moyenne) {
            index_max_moyenne = i;
        }
    }

    printf("Etudiant ayant la plus grande moyenne :\n");
    afficherInformations(T[index_max_moyenne]);

    trierParMoyenneDecroissante(T, 5);

    printf("Tableau trie par moyenne decroissante :\n");
    for (i = 0; i < 5; ++i) {
        afficherInformations(T[i]);
    }

    return 0;
}

