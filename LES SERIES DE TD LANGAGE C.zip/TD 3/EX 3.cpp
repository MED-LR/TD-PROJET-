


#include <stdio.h>
//1:
int main() {
    float t[3][4] = {{1.1, 2.2, 3.3, 4.4},
                     {5.5, 6.6, 7.7, 8.8},
                     {9.9, 10.1, 11.11, 12.12}};

    float somme = 0.0;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            somme += t[i][j];
        }
    }

    printf("La somme des elements du tableau T est : %.2f\n", somme);



//2:


    float *ptr = &t[0][0];

    for (int i = 0; i < 3 * 4; i++) {
        somme += *(ptr + i);
    }

    printf("La somme des elements du tableau T est : %.2f\n", somme);

    return 0;
}

