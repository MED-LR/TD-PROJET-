#include <stdio.h>

int search(float tableau[], int taille, float valeur) {
    for (int i = 0; i < taille; ++i) {
        if (tableau[i] == valeur) {
            return i;  
        }
    }
    return -1; 
}

int main() {
    int taille;
    
    printf("Entrez la taille du tableau : ");
    scanf("%d", &taille);

    float tableau[taille];

    
    for (int i = 0; i < taille; ++i) {
        printf("Entrez la valeur %d : ", i + 1);
        scanf("%f", &tableau[i]);
    }

    
    float valeurRecherchee;
    printf("Entrez la valeur a rechercher : ");
    scanf("%f", &valeurRecherchee);

    
    int position = search(tableau, taille, valeurRecherchee);

    
    if (position != -1) {
        printf("La valeur %.2f a ete trouvee a la position %d dans le tableau.\n", valeurRecherchee, position+1);
    } else {
        printf("La valeur %.2f n'a pas ete trouvee dans le tableau.\n", valeurRecherchee);
    }

    return 0;
}

