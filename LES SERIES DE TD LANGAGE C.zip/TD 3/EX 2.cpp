
#include <stdio.h>
#include <stdlib.h>

#define MAX_LENGTH 30

int estPalindrome(char *mot);

int main() {
    char mot[MAX_LENGTH];

    printf("Entrez un mot: ");
    scanf("%s", mot);

    if (estPalindrome(mot)) {
        printf("%s est un palindrome.\n", mot);
    } else {
        printf("%s n'est pas un palindrome.\n", mot);
    }

    return 0;
}

int estPalindrome(char *mot) {
   
    int longueur = 0;
    while (mot[longueur] != '\0') {
        longueur++;
    }


    char *debut = mot;
    char *fin = mot + longueur - 1;


    while (debut < fin) {
        if (*debut != *fin) {
            return 0; 
        }

        debut++;
        fin--;
    }

    return 1;
}




