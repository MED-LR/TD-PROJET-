
#include <stdio.h>
#include <string.h>

int frequencyOfWord(const char *phrase, const char *mot) {
    int count = 0;
    int phraseLength = strlen(phrase);
    int motLength = strlen(mot);

    for (int i = 0; i <= phraseLength - motLength; ++i) {
        // V�rifier si le mot correspond � la sous-cha�ne de la phrase
        if (strncmp(phrase + i, mot, motLength) == 0) {
            // Incr�menter le compteur si le mot est trouv�
            ++count;
        }
    }

    return count;
}

int main() {
    const char *phrase = "Bienvenue dans le monde du langage C. Le langage C est puissant.";
    const char *mot = "langage";

    int resultat = frequencyOfWord(phrase, mot);

    printf("Le mot '%s' apparait %d fois dans la phrase.\n", mot, resultat);

    return 0;
}


