#include <stdio.h>

main(){
/*La premi�re boucle for remplit le tableau de mani�re lin�aire avec les valeurs de 0 � 14.
Les instructions suivantes modifient des �l�ments sp�cifiques du tableau :
**b = 15; affecte la valeur 15 � b[0][0].
**(b + 1) = 16; affecte la valeur 16 � b[0][1].
*(b[0] + 1) = 17; affecte la valeur 17 � b[0][1].
*(*b + 8) = 18; affecte la valeur 18 � b[1][3].
*(*(b + 1) + 5) = 20; affecte la valeur 20 � b[1][0] (c'est-�-dire, � la deuxi�me ligne, premier �l�ment).
*(b[2] + 3) = 21; affecte la valeur 21 � b[2][3].
*(*(b + 2) + 2) = 22; affecte la valeur 22 � b[2][2].
Enfin, le programme affiche le tableau modifi�.*/
	
	
int b[3][5];
int *a = *b,i;
for(i=0;i<15;*a++ = i++);   




**b = 15;


**(b+1) = 16;


*(b[0]+1) = 17;



*(*b+8) = 18;



*(b[1]+2) = 19;


*(b[2] + 3) = 21;

*(*(b + 2) + 2) = 22;


 


for(i=0;i<3;i++)
{
	for(int j=0;j<5;j++)
	{
		printf("\t%d",b[i][j]);
	}
	printf("\n");

}

	
}

