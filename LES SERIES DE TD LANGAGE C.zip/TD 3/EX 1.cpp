#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGTH 30

void inverserNom(char *nom);

int main() {
    char *nom = (char *)malloc(MAX_LENGTH * sizeof(char));

    if (nom == NULL) {
        printf("Allocation de memoire echouee.\n");
        return 1;
    }

    printf("Entrez un nom : ");
    scanf("%s", nom);

    inverserNom(nom);

    printf("Nom inverse : %s\n", nom);

    free(nom);

    return 0;
}

void inverserNom(char *nom) {

    char *debut = nom;
    char *fin = nom + strlen(nom) - 1;

    while (debut < fin) {
        if (*debut != ' ' && *fin != ' ') {
            char temp = *debut;
            *debut = *fin;
            *fin = temp;
        }

        debut++;
        fin--;
    }
}


