#include <stdio.h>

int main() {
    int nombreLignes, i, j;

    printf("Entrez le nombre de lignes pour le triangle isocele : ");
    scanf("%d", &nombreLignes);

    for (i = 1; i <= nombreLignes; i++) {

        for (j = 1; j <= nombreLignes - i; j++) {
            printf(" ");
        }

        for (j = 1; j <= 2 * i - 1; j++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}
