
#include <stdio.h>

int main() {
    float num1, num2, result;
    char op;

    printf("Entrez deux nombres : ");
    scanf("%f %f", &num1, &num2);

    printf("Entrez une op�ration (+, -, *, /) : ");
    scanf(" %c", &op);

    switch (op) {
        case '+':
            result = num1 + num2;
            printf("Addition : %.2f + %.2f = %.2f\n", num1, num2, result);
            break;
        case '-':
            result = num1 - num2;
            printf("Soustraction : %.2f - %.2f = %.2f\n", num1, num2, result);
            break;
        case '*':
            result = num1 * num2;
            printf("Multiplication : %.2f * %.2f = %.2f\n", num1, num2, result);
            break;
        case '/':
            if (num2 != 0.0f) {
                result = num1 / num2;
                printf("Division : %.2f / %.2f = %.2f\n", num1, num2, result);
            } else {
                printf("La division par zero n'est pas autorisee.\n");
                return 1;
            }
            break;
        default:
            printf("Operation invalide.\n");
            return 1;
    }

    return 0;
}


