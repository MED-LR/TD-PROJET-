#include <stdio.h>

#include <stdio.h>

int main() {
    int copies;
    double cout;

    printf("Entrez le nombre de photocopies : ");
    scanf("%d", &copies);

    if(copies <= 10) {
        cout = copies * 1.0;
    } else if(copies <= 30) {
        cout = 10 + (copies - 10) * 0.6;
    } else {
        cout = 10 + 20 * 0.6 + (copies - 30) * 0.4;
    }

    printf("Cout total : %.2f DH\n", cout);
    return 0;
}



