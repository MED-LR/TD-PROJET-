#include <stdio.h>

int main() {
    int i, num, evenCount = 0;
    
    int nombre, countEntries = 0, countPairs = 0;

    // Part 1




    printf("Entrez 20 nombres :\n");

    for (int i = 0; i < 20; i++) {
        printf("Nombre %d : ", i + 1);
        scanf("%d", &nombre);

        if (nombre % 2 == 0) {
            printf("Le carre du nombre pair est : %d\n", nombre * nombre);
            countPairs++;
        }
    }

    printf("Nombre total d'entrees paires : %d\n", countPairs);


    // Part 2


    printf("Entrez une serie de nombres. Saisissez 100 pour arr�ter :\n");

    while (1) {
        printf("Nombre : ");
        scanf("%d", &nombre);

        if (nombre == 100) {
            break;
        }

        countEntries++;

        if (nombre % 2 == 0) {
            printf("Le carre du nombre pair est : %d\n", nombre * nombre);
            countPairs++;
        }
    }

    printf("Nombre total d'entrees : %d\n", countEntries);
    printf("Nombre total d'entrees paires : %d\n", countPairs);

    return 0;
}
