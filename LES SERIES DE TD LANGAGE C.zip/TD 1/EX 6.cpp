
#include <stdio.h>

int main() {
    int num, i;

    printf("Entrez un nombre : ");
    scanf("%d", &num);

    if (num % 2 == 0) {
        printf("Les nombres pairs jusqu'a %d sont :\n", num);
        for (i = 2; i <= num; i += 2) {
            printf("%d \t ", i);
        }
        printf("\n");
    } else {
        printf("Le nombre n'est pas pair.\n");
    }

    return 0;
}
