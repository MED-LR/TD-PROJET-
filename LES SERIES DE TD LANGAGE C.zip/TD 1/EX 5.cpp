
#include <stdio.h>
int main() {
    int num, i;
    bool estPremier = true;

    printf("Entrez un nombre : ");
    scanf("%d", &num);

    if (num <= 1) estPremier = false;
    for (i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            estPremier = false;
            break;
        }
    }

    if (estPremier) {
        printf("%d est un nombre premier.\n", num);
    } else {
        printf("%d n'est pas un nombre premier.\n", num);
    }

    return 0;
}
