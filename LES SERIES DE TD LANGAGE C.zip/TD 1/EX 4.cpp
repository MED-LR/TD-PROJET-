
#include <stdio.h>

int main() {
    float prix, remise;

    printf("Entrez le prix d'origine : ");
    scanf("%f", &prix);

    if (prix < 100) {
        remise = prix * 0.30;
    } else if (prix <= 200) {
        remise = prix * 0.40;
    } else {
        remise = prix * 0.50;
    }

    printf("Prix d'origine : %.2f DH\n", prix);
    printf("Remise : %.2f DH\n", remise);
    printf("Prix final : %.2f DH\n", prix - remise);

    return 0;
}
