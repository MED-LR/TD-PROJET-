
#include <stdio.h>

main() {
    int taille, i, j;

    printf("Veuillez entrer la taille de la figure : ");
    scanf("%d", &taille);

    for (i = 1; i <= taille; i++) {
        for (j = 1; j <= taille; j++) {
            if (i == 1||i == taille||j == 1||j == taille)
                printf("* ");
                
            else if (i == j ||j == taille-i+1)
            printf("+ ");
            else if (i == (taille+1)/2 ||j == (taille+1)/2 )
            printf("- ");
            else
                printf("  ");
        }
        printf("\n");
        
		}

}


