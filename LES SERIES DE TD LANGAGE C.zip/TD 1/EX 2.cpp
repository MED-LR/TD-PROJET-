#include <stdio.h>

int main() {
    int age;
    char gender;
    
    printf("Entrez votre age :\n ");
    
    scanf("%d", &age);
    

    printf("Entrez votre genre (M/F) :\n ");
    
    getchar();
    scanf(" %c", &gender);

    if ((gender == 'M' && age >= 20) || (gender == 'F' && age >= 18 && age <= 35)) {
        printf("Vous etes imposable.\n");
    } else {
        printf("Vous n'etes pas imposable.\n");
    }

    return 0;
}


