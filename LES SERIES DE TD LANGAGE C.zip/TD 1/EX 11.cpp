#include <stdio.h>

int main() {
    int entier = 0;
    int choix;

    printf("Entrer un entier : ");
    scanf("%d", &entier);

    do {
        printf("Menu :\n");
        printf("1. Ajouter 2\n");
        printf("2. Multiplier par 3\n");
        printf("3. Soustraire 5\n");
        printf("4. Quitter\n");

        printf("Veuillez entrer votre choix (1-4) : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                entier += 2;
                printf("La nouvelle valeur de l'entier apres l'addition de 2 est : %d\n", entier);
                break;
            case 2:
                entier *= 3;
                printf("La nouvelle valeur de l'entier apres la multiplication par 3 est : %d\n", entier);
                break;
            case 3:
                entier -= 5;
                printf("La nouvelle valeur de l'entier apres la soustraction de 5 est : %d\n", entier);
                break;
            case 4:
                printf("Programme termin�.\n");
                break;
            default:
                printf("Choix invalide. Veuillez entrer un nombre entre 1 et 4.\n");
        }

    } while (choix != 4);

    return 0;
}


