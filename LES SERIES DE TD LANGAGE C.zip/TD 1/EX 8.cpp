#include <stdio.h>

int main() {
    int i, j;

    // Motif a
    for(i = 6; i > 0; i--) {
        for(j = 1; j <= i; j++) {
            printf("%d", j);
        }
        printf("\n");
    }

    printf("\n"); // Espace entre les motifs

    // Motif b
    for(i = 9; i > 0; i--) {
        for(j = 0; j < i; j++) {
            printf("%d", i);
        }
        printf("\n");
    }

    return 0;
}


