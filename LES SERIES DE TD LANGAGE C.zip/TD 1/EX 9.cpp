#include <stdio.h>

int main() {
    int nombre, totalValeurs = 0, somme = 0, minimum = 0;
    int sommePositives = 0, minimumPositives = 0;
    int estPremierNombre = 1;  // Utilis� pour d�terminer le minimum initial

    printf("Entrez une suite de nombres entiers (terminez par 999) :\n");

    while (1) {
        printf("Nombre : ");
        scanf("%d", &nombre);

        if (nombre == 999) {
            break;
        }

        totalValeurs++;
        somme += nombre;

        if (estPremierNombre || nombre < minimum) {
            minimum = nombre;
            estPremierNombre = 0;
        }

        if (nombre > 0) {
            sommePositives += nombre;

            if (estPremierNombre || (nombre < minimumPositives)) {
                minimumPositives = nombre;
            }
        }
    }

    printf("\nResultat : Le nombre total de valeurs de la suite est %d\n", totalValeurs);
    printf("Resultat : La somme des valeurs lues est %d\n", somme);
    printf("Resultat : Le minimum est %d\n", minimum);
    printf("Resultat : La somme des valeurs strictement positives est %d\n", sommePositives);
    printf("Resultat : Le minimum des valeurs strictement positives est %d\n", minimumPositives);

    return 0;
}
